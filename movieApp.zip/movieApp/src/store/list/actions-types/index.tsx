export enum ActionType {
  LIST_INIT = 'list_init',
  LIST_GET_SUCCESS = 'list_get_success',
  LIST_GET_FAILED = 'list_get_failed',
  LIST_ADD = 'LIST_ADD',
  LIST_DELETE = 'LIST_DELETE',
}
