export default {
  VIEW_MOVIES: 'VIEW MOVIES',
  HOME_SCREEN: 'Home Screen',
  LIST_SCREEN: 'List Screen',
  CREATE_LIST: 'Create List',
  SELECT_MOVIES: 'Select Movies',
};
