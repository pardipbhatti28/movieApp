export const movies = [
  {
    id: 1,
    image:
      'https://lumiere-a.akamaihd.net/v1/images/encanto-sg-poster_ea92a8ae.jpeg',
    title: 'The Shawshank Redemption',
    year: 1994,
    director: 'Frank Darabont',
    duration: '2h 22min',
    genre: ['Crime', 'Drama'],
    rate: 9.3,
  },
  {
    id: 2,
    image:
      'https://www.parents.com/thmb/qa3XNRsSmkXq7leOxZYjVgNe-tY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Screen-Shot-2022-01-24-at-12.04.22-PM-853dbdcf6f9942329351332ce809c2e0.png',
    title: 'The Godfather',
    year: 1972,
    director: 'Francis Ford Coppola',
    duration: '2h 55min',
    genre: ['Crime', 'Drama'],
    rate: 9.2,
  },
  {
    id: 3,
    image:
      'https://lumiere-a.akamaihd.net/v1/images/encanto-sg-poster_ea92a8ae.jpeg',
    title: 'The Shawshank Redemption',
    year: 1994,
    director: 'Frank Darabont',
    duration: '2h 22min',
    genre: ['Crime', 'Drama'],
    rate: 9.3,
  },
  {
    id: 4,
    image:
      'https://www.parents.com/thmb/qa3XNRsSmkXq7leOxZYjVgNe-tY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Screen-Shot-2022-01-24-at-12.04.22-PM-853dbdcf6f9942329351332ce809c2e0.png',
    title: 'The Godfather',
    year: 1972,
    director: 'Francis Ford Coppola',
    duration: '2h 55min',
    genre: ['Crime', 'Drama'],
    rate: 9.2,
  },
  {
    id: 5,
    image:
      'https://lumiere-a.akamaihd.net/v1/images/encanto-sg-poster_ea92a8ae.jpeg',
    title: 'The Shawshank Redemption',
    year: 1994,
    director: 'Frank Darabont',
    duration: '2h 22min',
    genre: ['Crime', 'Drama'],
    rate: 9.3,
  },
  {
    id: 6,
    image:
      'https://www.parents.com/thmb/qa3XNRsSmkXq7leOxZYjVgNe-tY=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/Screen-Shot-2022-01-24-at-12.04.22-PM-853dbdcf6f9942329351332ce809c2e0.png',
    title: 'The Godfather',
    year: 1972,
    director: 'Francis Ford Coppola',
    duration: '2h 55min',
    genre: ['Crime', 'Drama'],
    rate: 9.2,
  },
];
